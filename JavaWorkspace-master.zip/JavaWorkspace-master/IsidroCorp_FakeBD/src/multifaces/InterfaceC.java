package multifaces;

public interface InterfaceC {
	public void metodoC1();
	public void metodoC2();

}
