package multifaces;

public interface InterfaceA {
	public void metodoA1();
	public void metodoA2();

}
