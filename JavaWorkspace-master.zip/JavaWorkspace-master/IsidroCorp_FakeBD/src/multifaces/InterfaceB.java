package multifaces;

public interface InterfaceB {
	public void metodoB1();
	public void metodoB2();

}
