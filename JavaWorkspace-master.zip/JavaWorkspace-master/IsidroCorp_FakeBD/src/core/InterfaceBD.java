package core;

public interface InterfaceBD {
	public void conectar();
	public void desconectar();
	public void executarComando(String comando);

}
