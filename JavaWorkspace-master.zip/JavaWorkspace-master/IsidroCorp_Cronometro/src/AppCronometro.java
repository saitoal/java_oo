
public class AppCronometro {
	public static void main(String args[]) {
		TelaCronometro t = new TelaCronometro();
	}

}
