package datainterface;

public interface InterfaceBD {
	public void salvarNoBanco();
	public void recuperarDoBanco();
}
